# Perform Strong Correlated LD block analysis on the
# Knowledge Based SNP sets.

library(haploR) 
Sys.time()
strong_ld <- sapply(snp_list, function(x) {
  # ldThresh = 0.8 attribute signifies the r^2 is greater than 0.8
  
  haplo_res <- as.data.frame(
    queryHaploreg(query = x,ldThresh = 0.8, timeout = 100))
  
  haplo_res <- haplo_res$rsID
  return(haplo_res)
})
Sys.time()

# strong_ld is a nested list of all SNPs which are in LD Block
# for the Knowledge Based SNPs

#######################################################################
# Converting a nested list into a dataframe
# Rownames are the Knowledge Based SNPs
# each column has LD SNP to that particular SNPs

indx <- sapply(strong_ld, length)
#indx <- lengths(lst)
strong_ld_df <- as.data.frame(do.call(rbind,lapply(strong_ld, `length<-`,
                                                   max(indx))))
library(data.table)
strong_ld_df<- setDT(strong_ld_df, keep.rownames = TRUE)[]
row.names(strong_ld_df)<- strong_ld_df$rn

trial <- strong_ld_df
trial$names <- trial$rn
library(reshape2)
trial <- melt(trial, id.vars="names")
trial <- subset(trial, select = c(names,value))
i <- which(is.na(trial$value))
trial <- trial[-i,]
i <- duplicated(trial)
trial <- trial[!i,]

melted_strong_ld_df <- trial
names(melted_strong_ld_df) <- c("Knowledge_SNPs","LD_SNP")
unique_strong_ld_snps <- unique(trial$value)

# run on a server

library(doParallel)
library(foreach)
n.cores <- detectCores()

cl <- makeCluster(n.cores)
registerDoParallel(cl)

X3 <- foreach(i=1:length(unique_strong_ld_snps), .combine = rbind, .multicombine = TRUE) %dopar% { 
  # package rsnps is used to query NCBI for each SNP and get the
  # respective Gene associated to that SNP from dbSNP database
     library(rsnps)
     dbSNP_result <- lapply(unique_strong_ld_snps[i], function(y) {
         results <- ncbi_snp_query(y, timeout=100)
         # Fetching only rsIDs as "Query" and "Gene"
         results <- results[,c("Query","Gene")]
         
         })
   }


gene_snp_map <- as.vector(X3[,1])

# gene_snp_map is a nested list

indx <- sapply(gene_snp_map, length)

gene_snp_map <- as.data.frame(do.call(rbind,lapply(gene_snp_map, `length<-`,
                                                   max(indx))))

# Certain SNPs donot have any Gene information on dbSNP
# so removing those NA SNPs
i <- which(is.na(gene_snp_map$Gene))
gene_snp_map <- gene_snp_map[-i,]
names(gene_snp_map)[1] <- "rsID"


################################################################

# mapping all knowledge based SNPs to their respective
# strong_ld SNPs and further on to the genes for each LD_SNP
# this means in melted_strong_ld_df we have knowledge based SNPs to
# all associated Genes.

melted_strong_ld_df$Gene <- gene_snp_map$Gene[match(melted_strong_ld_df$LD_SNP,
                                                  gene_snp_map$rsID)]


######################################################################
# mapping each rsid to Gene symbol can be done from Biomart but is very
# time consuming. one can still use these functions for mapping RsIDs to
# HGNC gene Symbols.

# source("https://bioconductor.org/biocLite.R")
# biocLite("biomaRt")
# library(biomaRt)
# snp = useEnsembl(biomart="snp", dataset = "hsapiens_snp")
# 
# 
# getENSG <- function(rs , mart = snp) {
#   
#   # val <- seq(1,23,1)
#   result <- getBM(attributes=c('refsnp_id','ensembl_gene_stable_id'), filters ='snp_filter', values =rs, mart = snp)
#   return(result)
# }
# gene_snp <- getENSG(rs= unique_strong_ld_snps)
# 
# ensembl_id <- gene_snp$ensembl_gene_stable_id
# 
# ensembl <- useEnsembl(biomart="ensembl", dataset = "hsapiens_gene_ensembl")
# 
# getHGNC <- function(ensmbl_id , mart = ensembl) {
#   
#   # val <- seq(1,23,1)
#   result_hgnc <- getBM(attributes=c('ensembl_gene_id','hgnc_symbol'), filters ='ensembl_gene_id', values =ensmbl_id, mart = ensembl)
#   return(result_hgnc)
# }
# result_hgnc <- getHGNC(ensembl_id)

# save.image("14jun_gene_snpmap.RData")

