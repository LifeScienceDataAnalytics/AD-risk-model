# Download eQTL Datasets from GTeX Portal specific to brain tissue
# https://www.gtexportal.org/home/datasets
# these are already loaded Dataframes of Brain
brain_eqtls <- as.data.frame(rbind(brain_accumbens_subset,brain_anterior_cingulate_cortex_subset,
                                   brain_caudate_basal_ganglia_subset, brain_cerebellar_hemisphere_subset,
                                   brain_cerebellum_subset, brain_cortex_subset,
                                   brain_frontal_cortex_subset, brain_hippocampus_subset,
                                   brain_hypothalamus_subset, brain_putamen_subset))

save(brain_eqtls, file = "brain_eqtls.RData")


i <- duplicated(brain_eqtls)
eqtls_brain <- brain_eqtls[!i,]

eqtls_brain <- eqtls_brain[,c(1,2)]

i <- duplicated(eqtls_brain)

# All cis eQTLs related to Brain Tissue are in this variable.
eqtls_brain <- eqtls_brain[!i,]

rm(brain_eqtls,i)

ensemble_id <- eqtls_brain[,1]
ensemble_id <- sapply(ensemble_id, FUN = function(x) strsplit(x, "[.]"))
ensemble_id <- unlist(ensemble_id)[ c(TRUE,FALSE) ]


ensemble_id <- as.character(ensemble_id)

i <- duplicated(ensemble_id)
unique_ensembl_id <- ensemble_id[!i]
write(unique_ensembl_id, file = "unique_gene_ensembl_id.txt")

# Get all the Genes related to all 23 pair of chromosomes.

library(biomaRt)

ensembl = useEnsembl(biomart="ensembl", dataset="hsapiens_gene_ensembl")
val <- seq(1,23,1)
chr_genes <- getBM(attributes=c('ensembl_gene_id',
                                'hgnc_symbol','chromosome_name','start_position','end_position'), filters =
                     'chromosome_name', values =val, mart = ensembl)


chr_genes$hgnc_symbol <- gsub("^$", NA, chr_genes$hgnc_symbol)

chr_genes <- chr_genes[which(!is.na(chr_genes$hgnc_symbol)),]

# Formatting eQTL brain IDs in standard Ensembl Gene IDs
eqtls_brain$gene_id <- gsub("\\.[0-9]+","", eqtls_brain$gene_id)


# converted ensemble id to HGNC symbol from 
# https://biodbnet-abcc.ncifcrf.gov/db/db2db.php
converted <- read.csv("converted.csv")
names(converted) <- c("ensembl_gene_id", "hgnc_symbol")
i <- grep("^\\-", converted$HGNC)
converted <- converted[-i,]

# get only "ensembl_gene_id", "hgnc_symbol"
chr_genes_1 <- chr_genes[,c(1,2)]
chr_genes_1 <- as.data.frame(rbind(chr_genes_1,converted))
i <- duplicated(chr_genes_1)
chr_genes_1 <- chr_genes_1[!i,]

###################################################################
# merge eQTL brain specific data with Symbols

eqtls_brain$hgnc <- chr_genes_1$hgnc_symbol[match(eqtls_brain$gene_id,
                                                  chr_genes_1$ensembl_gene_id)]

###################################################################
# convert Variant ID into RSID. The eQTL data Variant ID 
# was of the format "chromossome_Position_allele.. etc"

eqtl_hgnc_variant_id <- eqtls_brain
eqtl_hgnc_variant_id$var_loc <- 0
eqtl_hgnc_variant_id$var_loc  <- sapply(eqtl_hgnc_variant_id$variant_id, FUN = function(x) strsplit(x, "[_]"))
eqtl_hgnc_variant_id$chr <- rapply(eqtl_hgnc_variant_id$var_loc, function(x) unlist(x)[ c(T,F,F,F,FALSE) ], how = "replace")

eqtl_hgnc_variant_id$var_loc <- rapply(eqtl_hgnc_variant_id$var_loc, function(x) unlist(x)[ c(F,T,F,F,FALSE) ], how = "replace")

eqtl_hgnc_variant_id$chr_loc <- paste(eqtl_hgnc_variant_id$chr,eqtl_hgnc_variant_id$var_loc, sep = "_")
####################################################################


# Package SNPlocs.Hsapiens.dbSNP.20120608
# contains SNP and Location data.

source("https://bioconductor.org/biocLite.R")
biocLite("SNPlocs.Hsapiens.dbSNP.20120608")
library(SNPlocs.Hsapiens.dbSNP.20120608)

# get all chromosome names
chromosome_names <- getSNPcount()
chromosome_names <- names(chromosome_names)
result_bind <- NULL

# this forloop fetches all the SNPs from the respective chromosomes
# present in dbSNP database
for (j in chromosome_names){
  res_dbsnp <- as.data.frame(getSNPlocs(j) )
  res_dbsnp$chr <- j 
  result_bind <- as.data.frame(rbind(result_bind, res_dbsnp))
  
}

result_bind$chr <- gsub("ch","",result_bind$chr)
result_bind$chr_loc <- paste(result_bind$chr,result_bind$loc,sep = "_")
result_bind$RefSNP_id <- paste("rs",result_bind$RefSNP_id, sep = "")
####################################################################
# merge eQTL SNPs with RsIDs


snp_gene_location <- merge(eqtl_hgnc_variant_id, result_bind, by ="chr_loc", all =F)
snp_gene_location$RefSNP_id <- paste("rs",snp_gene_location$RefSNP_id, sep = "")

i <- unique(snp_gene_location$RefSNP_id)

#
# unclass(by(snp_gene_location, snp_gene_location$RefSNP_id, function(x) {
#   tmp <- x$hgnc_symbol
#   setNames(tmp, x$RefSNP_id[1])
#   tmp
# })) -> df
# 
# df <- as.list(df)

##################################################################

# read trans-eQTL dataset 
trans_eqtls <- read.csv("trans_eqtls.csv")

i <- which(trans_eqtls[,1] %in% snp_gene_location$RefSNP_id)
trans_eqtls <- trans_eqtls[-i,]

trans_eqtls_list <- as.list(trans_eqtls$gene_name)
names(trans_eqtls_list) <- trans_eqtls[,1]
