library(pec)
library(Hmisc)

source('~/R/PredictiveModeling/integrative.model.R')
source('~/R/PredictiveModeling/train.R')

crossval = function(x, y, nreps=10, nfolds=10, seed=1234, hyper){
  set.seed(seed)
  features = list()
  myauc = matrix(NA, ncol=nreps, nrow=nfolds)
  kk = 1
  pf = list()
  for(r in 1:nreps){
    perm = sample(1:NROW(y))
    for(k in 1:nfolds){
      cat(".")
      tst = perm[seq(k, NROW(y), by=nfolds)]
      trn = setdiff(1:NROW(y), tst)
      xtrn = xtst = list()
      for(i in 1:length(x)){
        xtrn[[names(x)[i]]] = x[[i]][trn,]
        xtst[[names(x)[i]]] = x[[i]][tst,]
      }
      ytrn = y[trn,]
      
      fit = train.integrative.model(xtrn, ytrn, hyper[[1]], hyper[[2]], hyper[[3]], hyper[[4]], hyper[[5]])
      features[[kk]] = fit$features
      pred = test.integrative.model(fit, xtst, hyper[[1]])
      
      lam = basehaz.gbm(y[tst,1], y[tst,2], pred, smooth=TRUE, t.eval = c(0, unique(sort((y[,1]))))) # cumulative hazard function
      LAM = matrix(rep(lam,length(pred)), byrow=TRUE, ncol=length(lam)) # baseline cumulative hazards
      PRED = matrix(rep(exp(pred), length(lam)), ncol=length(lam)) # predictors from GBM ==> relative risk
      pred.prob = exp(-LAM)^PRED # survival probabilities according to Cox model (Eq. 7.11)

      df = data.frame(time=y[tst,1], event=y[tst,2])
      pf[[kk]] = pec(pred.prob, formula=Surv(time,event) ~ 1, data=df, times=c(0, unique(sort((y[,1])))), exact=FALSE)
      myauc[k,r] = 1 - rcorr.cens(pred, y[tst,])[1]
      kk = kk + 1
      cat("performance = ", myauc[k,r], "\n")
    }    
  }
  list(perf=colMeans(myauc, na.rm = TRUE), features=features, pred.err.curves=pf)
}  
