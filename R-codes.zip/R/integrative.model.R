# integrative modeling strategies
library(gbm)
library(parallel)
library(SNPRelate)
library(randomForestSRC)
library(mixOmics)
library(PMA)
#source('~/R/PredictiveModeling/train.R')

# X: list of feature matrices, one for clinical & SNP_pathway_burden, rownames correspond to patient IDs and have to match
# y: Surv object (time-to-event), factor (classification) or numerical value (regression) - rownames correspond to patient IDs
# gdsfile: GDS file (see SNPRelate package tutorial) with patient genotypes (rows = ALL SNPs measured in both ADNI-1 and ADNI-2/GO)
# all.snps: set of all (LD pruned) SNPs in these data
# sel.snp: IDs of SNPs to consider in gdsobj (= ~312 knowledge based SNPs). If NULL, all SNPs are considered
# n.cores: #CPU cores for parallel computing
# method: (sep.sel = separate feature selection for each data modality followed by GBM training, simple = one GBM model, RSF = Random Survival Forest, glmnet = elastic net, CCA = Regularized Generalized CCA followd by Cox regression)
# returns: list (pca = PCA results, fit=final GBM model, orig.features=list of original features to fit final GBM model, features=selected features by final GBM model, best.iter=optimal number of boosting steps, sel.snp=knowledge based SNPs)
train.integrative.model = function(X, y, gdsfile=NULL, all.snps=NULL, sel.snp=NULL, n.cores=10, method=c("sep.sel", "simple", "RSF", "glmnet", "CCA", "PMA")){
  method = match.arg(method)
  yy = y
  if(is.Surv(y)){
    distribution = "coxph"
    family = "cox"
  }
  else if(is.factor(y)){
    if(length(unique(y)) == 2){
      distribution = "bernoulli"
      family = "binomial"
      if(method != "simple-glmnet")
        yy = as.numeric(y) - 1
    }
    else
      family = distribution = "multinomial"
  }
  else
    distribution = "huber"
  # fast PCA using first principal components only
  if(!is.null(gdsfile)){
    gdsobj = snpgdsOpen(gdsfile, allow.duplicate = TRUE)
    if(!is.null(sel.snp))
      sel.snp <- snpgdsLDpruning(gdsobj, ld.threshold=0.2, sample.id=rownames(X[[1]]), snp.id=sel.snp, maf=0.01, missing.rate=0.05)
    if(is.null(all.snps))
      snpset2 <- snpgdsLDpruning(gdsobj, ld.threshold=0.2, sample.id=rownames(X[[1]]), num.thread=n.cores, maf=0.01, missing.rate=0.05)
    else
      snpset2 = all.snps
    pr = snpgdsPCA(gdsobj, sample.id=rownames(X[[1]]), snp.id=unlist(snpset2), bayesian=TRUE, maf=0.01, missing.rate=0.05, num.thread=n.cores)
    print(cumsum(pr$varprop))
    #plot(pr$eigenvect[,1], pr$eigenvect[,2], xlab="PC1", ylab="PC2")
    X$SNP_PC = pr$eigenvect # eigenvectors represent global population structure
    colnames(X$SNP_PC) = paste("EV", 1:NCOL(X$SNP_PC), sep="")
    if(is.null(X$SNP)){
      if(!is.null(sel.snp))
        X$SNP = retrieve.snp.matrix(gdsobj, gdsfile, unlist(sel.snp), rownames(X[[1]])) # knowledge based SNPs corrected for LD
      else
        X$SNP = retrieve.snp.matrix(gdsobj, gdsfile, NULL, rownames(X[[1]])) # all SNPs corrected for LD
    }
    snpgdsClose(gdsobj)
  }
  # I. train separate GBM models for feature selection
  Xtot = NULL
  group.idx = c()
  for(i in 1:length(X)){
    cat(names(X)[i], "\n")
    if(method == "sep.sel"){
      idepth = 3
      fit = gbm(yy ~., data=data.frame(X[[i]]), distribution=distribution, interaction.depth=idepth, cv.folds=10, n.trees=pmax(15*NCOL(X[[i]]), 15000), n.cores=n.cores)
      best.iter = gbm.perf(fit, method="cv") # model selection based on cross-validation
      var.imp = summary(fit, plotit=FALSE, n.trees=best.iter)
      features = as.character(var.imp[var.imp[,2] > 0,"var"])
    }
    else{
      features = colnames(X[[i]])
    }
    group.idx = c(group.idx, rep(i, NCOL(X[[i]])))
    if(i > 1)
      Xtot = cbind.data.frame(Xtot, X[[i]][,features,drop=FALSE])
    else
      Xtot = X[[i]][, features,drop=FALSE]
  }
  # II. train final GBM model using all selected features
  cat("final model\n")
  best.iter = 0
  cca.res = NULL
  if(method %in% c("simple", "sep.sel")){
    fit.total = gbm(yy ~., data=data.frame(Xtot), distribution=distribution, interaction.depth=3, cv.folds=10, n.trees=pmax(15*NCOL(Xtot), 15000), n.cores=n.cores)
    best.iter = gbm.perf(fit.total, method="cv") # model selection based on cross-validation
    var.imp = summary(fit.total, plotit=FALSE, n.trees=best.iter)
    features = var.imp[var.imp[,2] > 0,]
  }
  else if(method == "RSF"){
    fit.total = rfsrc(Surv(time,event) ~ ., data=cbind.data.frame(time=yy[,1], event=yy[,2], Xtot), na.action="na.impute", importance="permute.ensemble")
    features = var.select(fit.total) # no feature selection to speed up calculations!
  }
  else if(method %in% c("glmnet")){
    fit.total = train.model(as.matrix(Xtot), yy, algo=method)
    features = fit.total$features
  }
  else if(method == "CCA"){
    J = length(X)
    C = matrix(1, J, J)
    diag(C) = 0
    for(i in 1:J){
      vars = apply(X[[i]], 2, var)
      X[[i]] = X[[i]][,vars>0]
    }
    cca.res = mixOmics(X=X, design=C, tau="optimal", ncomp=2)
    Xtmp2 = c()
    features = c()
    for(i in 1:length(cca.res$variates)){
      Xtmp2 = cbind(Xtmp2, X[[i]]%*%cca.res$loadings[[i]])
      features = c(features, selectVar(cca.res)[[i]]$value)
    }
    fit.total = coxph(yy ~ ., data=data.frame(Xtmp2))
  }
  else if(method == "PMA"){ # approach by Witten et al.
    J = length(X)
    for(i in 1:J){
      vars = apply(X[[i]], 2, var)
      X[[i]] = X[[i]][,vars>0]
      pvals = sapply(1:NCOL(X[[i]]), function(j) summary(coxph(yy~X[[i]][,j]))$logtest)["pvalue",]
      X[[i]] = X[[i]][,order(pvals)[1:floor(0.2*(NCOL(X[[i]])))]]
    }
    perm.out = MultiCCA.permute(xlist = X)
    print(perm.out)
    #plot(perm.out)
    cca.res = MultiCCA(xlist=X, penalty=perm.out$bestpenalties, ncomponents=2, ws=perm.out$ws.init)
    print(cca.res)
    Xtmp2 = c()
    features = c()
    for(i in 1:length(cca.res$ws)){
      Xtmp2 = cbind(Xtmp2, X[[i]]%*%cca.res$ws[[i]])
      rownames(cca.res$ws[[i]]) = colnames(X[[i]])
      features = c(features, colnames(X[[i]])[rowSums(cca.res$ws[[i]]) > 0])
    }
    fit.total = coxph(yy ~ ., data=data.frame(Xtmp2))
  }
  list(pca=pr, fit=fit.total, orig.features=colnames(Xtot), features=features, best.iter=best.iter, sel.snp=sel.snp, method=method, cca.res=cca.res)
}

# model: result returned by train.integrative.model
# Xtest: list of feature matrices (see train.integrative.model)
# gdsfile: see above
# sel.snp: see above
# n.cores: see above
# returns: vector of predictions (see predict.gbm)
test.integrative.model = function(model, Xtest, gdsfile=NULL, n.cores=10){
  # map SNPs to first principal components
  if(!is.null(gdsfile)){
    gdsobj = snpgdsOpen(gdsfile, allow.duplicate = TRUE)
    snpload = snpgdsPCASNPLoading(model$pca, gdsobj, num.thread=n.cores)
    SL = snpgdsPCASampLoading(snpload, gdsobj, sample.id=rownames(Xtest[[1]]))
    Xtest$SNP_PC = SL$eigenvect
    colnames(Xtest$SNP_PC) = paste("EV", 1:NCOL(Xtest$SNP_PC), sep="")
    if(is.null(Xtest$SNP))
        Xtest$SNP = retrieve.snp.matrix(gdsobj, gdsfile, unlist(model$sel.snp), rownames(Xtest[[1]]))
    snpgdsClose(gdsobj)
  }
  if(model$method != "CCA"){
    Xtest.tot = Xtest[[1]]
    for(i in 2:length(Xtest))
      Xtest.tot = cbind.data.frame(Xtest.tot, Xtest[[i]])
    Xtest.tot = Xtest.tot[,model$orig.features, drop=FALSE]
  }
  if(class(model$fit) == "gbm")
    pred = predict.gbm(model$fit, data.frame(Xtest.tot), n.trees=model$best.iter, type = "response")
  else if(class(model$fit) == "rsfrc")
    pred = predict.rfsrc(model$fit, data.frame(Xtest.tot), na.action="na.impute")$predicted
  else if(model$method == "CCA"){
   J = length(model$cca.res$variates)
   Xtmp = c()
   for(i in 1:J){
      Xtmp = cbind(Xtmp, Xtest[[i]][,rownames(model$cca.res$loadings[[i]])]%*%model$cca.res$loadings[[i]])
   }
   pred = predict(model$fit, newdata=data.frame(Xtmp))
  }
  else if(model$method == "PMA"){
    J = length(model$cca.res$ws)
    Xtmp = c()
    for(i in 1:J){
      Xtmp = cbind(Xtmp, Xtest[[i]][,rownames(model$cca.res$ws[[i]])]%*%model$cca.res$ws[[i]])
    }
    pred = predict(model$fit, newdata=data.frame(Xtmp))
  }
  else
    pred = predict.model(model$fit, Xtest.tot)
  pred
}

################################################################################
# helper function: get SNP matrix for selected SNPs and samples
# gdsobj: gds object
# sel.snp: see above
# sample.sel: sample IDs
retrieve.snp.matrix = function(gdsobj, gdsfile, snp.sel=NULL, sample.sel=NULL, n.cores=10){
  cl = makeCluster(getOption("cl.cores", n.cores))
  samples = clusterApply.gdsn(cl, gdsfile, "sample.id", margin=1, FUN=function(x) x, as.is="character")
  snps = clusterApply.gdsn(cl, gdsfile, "snp.id", margin=1, FUN=function(x) x, as.is="character")
  if(is.null(snp.sel))
    snp.sel = snps
  if(is.null(sample.sel))
    sample.sel = samples
  # snp.raw = do.call(rbind, clusterApply.gdsn(cl, gdsfile, "genotype", margin=2, FUN=function(x) x, selection=list(snps %in% snp.sel, samples %in% sample.sel))) # all data
  # #snp.raw = t(do.call(rbind, clusterApply.gdsn(cl, gdsfile, "genotype", margin=2, FUN=function(x) x, selection=list(samples %in% sample.sel, snps %in% snp.sel)))) # all data
  # dimnames(snp.raw) = list(samples[samples %in% sample.sel], snps[snps %in% snp.sel])
  # colnames(snp.raw) = make.names(colnames(snp.raw))
  stopCluster(cl)
  snp.raw <- snpgdsGetGeno(gdsobj, snp.id=snp.sel)
  colnames(snp.raw) = snp.sel
  rownames(snp.raw) = samples
  snp.raw = snp.raw[sample.sel,,drop=FALSE]
  snp.raw
}
