pathways$names <- rownames(pathways)
trial <- pathways
trial <- reshape(trial, idvar = "names", direction = "long", sep = "",
                 list(trial$names))
library(reshape2)
trial <- melt(trial, id.vars="names")
trial <- trial[,-2]
trial$value <- gsub("^$", NA, trial$value)
i <- which(is.na(trial$value))
trial <- trial[-i,]

pathway_gene_dataframe <- trial
save(pathway_gene_dataframe, file = "pathway_gene_dataframe.RData")
