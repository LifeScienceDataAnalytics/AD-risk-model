source('~/R/PredictiveModeling/integrative.model.R')
library(ggplot2)
library(Hmisc)
library(mclust)
library(doMC)
registerDoMC(cores=10)

gdsobj = snpgdsOpen("test.gds", allow.duplicate = TRUE)
snpset2 <- snpgdsLDpruning(gdsobj, ld.threshold=0.2, num.thread=10, maf=0.01, missing.rate=0.05)
ibd = snpgdsIBDMoM(gdsobj, maf=0.01, missing.rate=0.05, num.thread = 10, snp.id = unlist(snpset2), kinship=TRUE) # correct for relatedness
ibdcoef = snpgdsIBDSelection(ibd, 0.1)
pat = setdiff(rownames(adni.0), c(ibdcoef$ID1, ibdcoef$ID2))
inb = snpgdsIndInb(gdsobj, snp.id=unlist(snpset2), sample.id=pat, maf=0.01, missing.rate=0.05)
pat = pat[inb$inbreeding < 0.1]
pr = snpgdsPCA(gdsobj, snp.id=unlist(snpset2), sample.id=pat, bayesian=TRUE, maf=0.01, missing.rate=0.05, num.thread=10)
pdf(file="PCA.pdf")
plot(pr$eigenvect[,1], pr$eigenvect[,2], col=adni_demographics_979[pat,c("PTRACCAT")], xlab="PC1", ylab="PC2")
legend("bottomleft", legend=levels(adni_demographics_979[pat,c("PTRACCAT")]), pch="o", col=1:nlevels(adni_demographics_979[pat,c("PTRACCAT")]))
dev.off()
snpgdsClose(gdsobj)
 # GMM based clustering ==> identify sub-populations
mc = Mclust(pr$eigenvect, 1:5, modelNames="VVV", prior=priorControl(functionName="defaultPrior", "VVV"))
summary(mc)
plot(mc$BIC) # this is the *negative* BIC
plot(mc, "classification", dimens=1:2)

rownames(adni_demographics_979) = adni_demographics_979$PTID
adni.0 = cbind.data.frame(adni.0[pat,], adni_demographics_979[pat,c("PTGENDER", "PTEDUCAT", "PTETHCAT", "PTRACCAT", "PTMARRY")])
adni.0$subpopulation = factor(mc$classification)
pathway_burden = pathway_burden[pat,]
nna = apply(adni.0, 2, function(x) sum(is.na(x)))
adni.0 = adni.0[,nna < 0.65*NROW(adni.0)]
adni.0$DX.0 = factor(adni_demographics_979[pat, "DX.bl"])
colnames(pathway_burden) = make.names(colnames(pathway_burden))
pathway_burden = pathway_burden[,setdiff(colnames(pathway_burden), c("Signal.Transduction", "Metabolism", "Disease", "Gene.Expression", "Developmental.Biology", colnames(pathway_burden)[grep("cancer", colnames(pathway_burden))]))]
y = Surv(y[pat, "Event_Time"] + 6, y[pat, "AD_Flag"])
save(adni.0, pathway_burden, y, snpset2, snp_knowledge_adni, file="dat4model.rda")
set.seed(12345)
model_final = train.integrative.model(X=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), y=y, gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15)
pred = test.integrative.model(model_final, Xtest=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), gdsfile="test.gds")
save(model_final, pred, file="gbm_final.rda")

set.seed(12345)
model_final_simple = train.integrative.model(X=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), y=y, gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="simple")
pred.simple = test.integrative.model(model_final_simple, Xtest=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), gdsfile="test.gds")
save(model_final_simple, pred.simple, file="gbm_final_simple.rda")


myS = model_final$features[1:25,]
myS$var = factor(myS$var, levels=rev(unique(myS$var)))
ggplot(data=myS, aes(x=var,y=rel.inf), xlab="variable", ylab="relative influence") + geom_bar(stat="identity") + coord_flip()
ggsave(file="VariableInfluencesGBM.pdf")

rownames(model_final$features) = model_final$features$var
pathways = intersect(colnames(pathway_burden), model_final$features$var)
population = c(as.character(model_final$features$var[grep("EV", model_final$features$var)]),"subpopulation", "PTETHCAT", "PTRACCAT", "PTGENDER") # eigenvectors (subpopulations)
population = intersect(population, model_final$features$var)
#clin = setdiff(intersect(colnames(adni.0), model_final$features$var), c("APOE4.0", "subpopulation", "AD_Flag", "Event_Time"))
imaging = c("AV45.0", "FDG.0", as.character(model_final$features$var)[grep("Region_", as.character(model_final$features$var))]) # neuroimaging features
ntests = c("CDRSB.0", "ADAS11.0", "ADAS13.0", "MMSE.0", "FAQ.0", "MOCA.0", as.character(model_final$features$var)[grep("RAVLT", model_final$features$var)], as.character(model_final$features$var)[grep("Ecog", model_final$features$var)]) # neuropsychological test results
ntests = intersect(ntests, model_final$features$var)
snps = c(as.character(model_final$features$var)[grep("rs[0-9]+", model_final$features$var)], "APOE4.0") # SNPs / genetic markers
cuminfl = data.frame(feature.group=c("genomic overall", "SNPs", "pathways", "pop. struct.", "imaging", "psych./cogn."), 
                     rel.infl=c(sum(model_final$features[c(pathways, snps, as.character(model_final$features$var[grep("EV", model_final$features$var)])), "rel.inf"]),
                       sum(model_final$features[snps, "rel.inf"]),
                       sum(model_final$features[pathways, "rel.inf"]),
                       sum(model_final$features[population, "rel.inf"]),
                       sum(model_final$features[imaging, "rel.inf"]),
                       sum(model_final$features[ntests, "rel.inf"])
                       ))
ggplot(cuminfl, aes(x=feature.group, y=rel.infl)) + geom_bar(stat="identity", fill="steelblue") + coord_flip() + labs(y="relative influence (%)", x="feature group")
ggsave(file="CumInfl_FeatureGroups.pdf")

#  high risk vs. low risk patients
idx.normal = (y[,1] > 90 & y[,2] == 0 & adni.0$DX.0 == "CN")
idx.risk = (y[,1] <=12 & y[,2] == 1)
lam = basehaz.gbm(y[,1], y[,2], pred, smooth=TRUE, t.eval = unique(sort((y[,1])))) # cumulative hazard function
LAM = matrix(rep(lam,length(pred)), byrow=TRUE, ncol=length(lam)) # baseline cumulative hazards
PRED = matrix(rep(exp(pred), length(lam)), ncol=length(lam)) # predictors from GBM ==> relative risk
pred.prob = exp(-LAM)^PRED # cumulative hazard according to Cox model (Eq. 7.11)

pdf(file="HighRisk_LowRisk.pdf")
plot(sort(unique(y[,1])), seq(0,1,length.out = 9), type="n", xlab="time (months)", ylab="probability of being event-free")
lines(sort(unique(y[,1])), colMeans(pred.prob[idx.normal,]), type="l", col="blue")
lines(sort(unique(y[,1])), colMeans(pred.prob[idx.risk,]), type="l", col="red")
legend("bottomright", c("low risk: normal at EOS", "high risk: AD within 12 months"), fill=c("blue", "red"))
dev.off()

qp = quantile(pred, c(0.1, 0.5, 0.9))
haz.high_risk.m = colMeans(-log(pred.prob[pred > qp[3],]))
haz.high_risk.sd = sqrt(apply(-log(pred.prob[pred > qp[3],]), 2, sd))
haz.high_risk = data.frame(risk="high", time=unique(sort((y[,1]))), mean=haz.high_risk.m, lwr=pmax(0, haz.high_risk.m - haz.high_risk.sd), upr=haz.high_risk.m + haz.high_risk.sd)
haz.low_risk.m = colMeans(-log(pred.prob[pred < qp[1],]))
haz.low_risk.sd = sqrt(apply(-log(pred.prob[pred > qp[1],]), 2, sd))
haz.low_risk = data.frame(risk="low", time=unique(sort((y[,1]))), mean=haz.low_risk.m, lwr=pmax(0, haz.low_risk.m - haz.low_risk.sd), upr=haz.low_risk.m + haz.low_risk.sd)
haz.av_risk.m = colMeans(-log(pred.prob[pred >= qp[1] & pred <= qp[3],]))
haz.av_risk.sd = sqrt(apply(-log(pred.prob[pred >= qp[1] & pred <= qp[3],]), 2, sd))
haz.av_risk = data.frame(risk="average", time=unique(sort((y[,1]))), mean=haz.av_risk.m, lwr=pmax(0, haz.av_risk.m - haz.av_risk.sd), upr=haz.av_risk.m + haz.av_risk.sd)
library(ggplot2)
ggplot(rbind.data.frame(haz.high_risk, haz.low_risk), aes(time, mean))+ ylab("cumulative hazard")+
      geom_line(data=haz.high_risk, col="red")+
      geom_ribbon(data=haz.high_risk,aes(ymin=lwr,ymax=upr),alpha=0.3, fill="red")+
      geom_line(data=haz.low_risk, col="green")+
      geom_ribbon(data=haz.low_risk,aes(ymin=lwr,ymax=upr),alpha=0.3, fill="green")+ theme_bw()
ggsave(file="HighRisk_LowRisk_DataDriven.pdf")
# low risk: 74% CN, 24% EMCI; high risk: all MCI (97% LMCI)
# Unterschiede zwischen beiden Gruppen
source("BNlearning.R")
load(file="dat_full.rda")
dat.risk = cbind.data.frame(dat.full[pred > qp[3],-which(colnames(dat.full) %in% c("AD_Flag", "Event_Time"))], group="high risk")
dat.risk = rbind.data.frame(dat.risk, cbind.data.frame(dat.full[pred < qp[1],-which(colnames(dat.full) %in% c("AD_Flag", "Event_Time"))], group="low risk"))

dat.risk2 = cbind.data.frame(dat.full[pred > qp[3],], group="high risk")
dat.risk2 = rbind.data.frame(dat.risk2, cbind.data.frame(dat.full[pred < qp[1],], group="low risk"))
survdiff(Surv(Event_Time, as.numeric(AD_Flag)) ~ group, data=dat.risk2) #p = 0

pv = c()
pvname = c()
for(i in 1:(NCOL(dat.risk)-1)){
  if(length(unique(dat.risk$group[!is.na(dat.risk[,i])])) > 1 && colnames(dat.risk)[i] != "DX.0"){
    pvname = c(pvname, colnames(dat.risk)[i])
    if(is.numeric(dat.risk[,i]))
      pv = c(pv, wilcox.test(dat.risk[,i] ~ dat.risk$group)$p.value)
    else
      pv = c(pv, chisq.test(dat.risk[,i], dat.risk$group)$p.value)
  }
}
names(pv) = pvname
pv = p.adjust(pv, "BY")
for(p in names(pv)[pv < 0.2]){
  if(is.numeric(dat.risk[,p])){
    pdf(file=paste(p, ".pdf", sep=""))
    boxplot(dat.risk[,p] ~ dat.risk$group, main=paste(p, "(p = ", round(pv[p],2), ")"))
    dev.off()
  }
  else{
    tab = table(dat.risk[,p], dat.risk$group)
    df = melt(data.frame(round(t(apply(tab,1, function(x) x/colSums(tab))), 2)))
    colnames(df) = c("Var2", "Freq")
    df = cbind(df, data.frame(Var1 = rep(0:2, 2)))
    g <- ggplot(df, aes(Var1, Var2)) + ggtitle(paste(p, "(p = ", round(pv[p],2), ")")) + geom_point(aes(size = Freq), colour = "grey") + theme_bw() + xlab(p) + ylab("")
    g + scale_size_continuous(range=c(10,30)) + geom_text(aes(label = Freq))
    ggsave(file=paste(p, ".pdf", sep=""))
  }
}

source("crossval.R")
cv = crossval(x=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), y=y, hyper=list(gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="sep.sel"))
save(cv, file="crossvalidation_results.rda")

cv2 = crossval(x=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), y=y, hyper=list(gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="simple"))
save(cv2, file="cv_results_simpleGBM.rda")

cv3 = crossval(x=list(clinical=adni.0[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))], SNP_pathway_burden=pathway_burden), y=y, hyper=list(gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="RSF"))
save(cv3, file="cv_results_RSF.rda")

# dat.imp$ximp has to be loaded first!
Ximp.clinical = expand.df(dat.imp$ximp[,setdiff(colnames(adni.0), c("AD_Flag", "Event_Time"))])
Ximp.pathway = as.matrix(dat.imp$ximp[,colnames(pathway_burden)])
Ximp.SNP = dat.imp$ximp[,snp_knowledge_adni]
for(i in 1:NCOL(Ximp.SNP))
  Ximp.SNP[,i] = as.numeric(as.character(Ximp.SNP[,i]))
Ximp.SNP = as.matrix(Ximp.SNP)

cv4 = crossval(x=list(clinical=Ximp.clinical, SNP_pathway_burden=Ximp.pathway, SNP=Ximp.SNP), y=y, hyper=list(gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="glmnet"))
save(cv4, file="cv_results_EN.rda")

cv5 = crossval(x=list(clinical=Ximp.clinical, SNP_pathway_burden=Ximp.pathway, SNP=Ximp.SNP), y=y, hyper=list(gdsfile="test.gds", all.snps = unlist(snpset2), sel.snp = snp_knowledge_adni, n.cores=15, method="CCA"))
save(cv5, file="cv_results_CCA.rda")

dfcv = data.frame(method=rep(c("GBM", "RSF", "EN", "RGCCA+Cox"), each=10), cv=c(cv$perf, cv3$perf, cv4$perf, cv5$perf))
qplot(method, cv, data=dfcv, geom="boxplot", ylab="cross-validated C-index", fill=method) + theme_bw()
ggsave(file="PerfComparisonAll.pdf")

# C-index and prediction error curves
pdf(file="Cindex.pdf")
boxplot(cv$perf, main="10 x 10-fold cross-validation", ylab="Concordance")
dev.off()
err = lapply(cv$pred.err.curves, function(pf) summary(pf)$AppErr)
df = data.frame()
for(ti in unique(y[,1])){
  res = sapply(1:length(err), function(i) err[[i]][err[[i]][,"time"] == ti,3:4])
  m1 = mean(res[1,], na.rm=TRUE)
  m2 = mean(res[2,], na.rm=TRUE)
  sd1 = sd(res[1,], na.rm=TRUE)
  sd2 = sd(res[2,], na.rm=TRUE)
  df = rbind.data.frame(df, data.frame(time=ti, method="Kaplan-Meier", mean=m1, lwr=m1 - sd1, upr=m1 + sd1))
  df = rbind.data.frame(df, data.frame(time=ti, method="GBM", mean=m2, lwr=m2 - sd2, upr=m2 + sd2))
}
df = df[order(df$time),]
ggplot(df, aes(time, mean, fill=method))+ ylab("prediction error (Brier score)")+
  geom_line(data=df[df$method == "Kaplan-Meier",], col="black")+
  geom_ribbon(data=df[df$method == "Kaplan-Meier",],aes(ymin=lwr,ymax=upr),alpha=0.3)+
  geom_line(data=df[df$method == "GBM",], col="red")+
  geom_ribbon(data=df[df$method == "GBM",],aes(ymin=lwr,ymax=upr),alpha=0.3, fill="red")+
  theme_bw()
ggsave(file="predErrCurve.pdf")

freq = table(unlist(sapply(1:length(cv$features), function(i) rownames(cv$features[[i]]))))
freq = freq[order(freq, decreasing = TRUE)]
ff = data.frame(rev(freq[as.character(myS$var)]))
ggplot(data=ff, aes(x=Var1,y=Freq), xlab="variable", ylab="selection frequency") + geom_bar(stat="identity") + coord_flip() + theme_bw()
ggsave(file="VariableStabilityGBM.pdf")
