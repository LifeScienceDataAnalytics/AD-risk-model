# predictive analysis: training of final model, including feature selection; prediction
#################################################
library(kernlab)
library(glmnet)
library(h2o)
library(randomForest)
library(mboost)
library(doMC)
library(dummy)
library(gbm)
library(SGL)

source("../PredictiveModeling/svmRFE.R")
source("../PredictiveModeling/imputation.R")
options(error=recover)

h2o.init(nthreads = 10)
registerDoMC(cores=10)

train.model = function(xtrn_df, ytrn, compl=NULL, algo=c("gbm", "h2o-gbm", "gbm imp", "gamboost", "RF", "glmnet", "svm", "svm.linear", "SGL"), weights=NULL, only.completers=FALSE, inner.cv=5, hyper=NULL, max.feat=floor(NROW(xtrn)/3)){
  algo = match.arg(algo)    
  cat("algorithm: ", algo, "\n\n")
  if(is.null(weights))
    weights = rep(1, NROW(xtrn_df))
  if(is.factor(ytrn) && nlevels(ytrn) == 2)
    ytrn = factor(sign(as.numeric(ytrn) - 1.5))
  if(only.completers && !is.null(compl)){ # use only completers for training?
    xtrn_df = xtrn_df[compl, ]
    ytrn = ytrn[compl]
    weights = weights[compl]
  }
  if(!(algo %in% c("gbm", "h2o-gbm")))
    xtrn_df = impute.trn(xtrn_df)
  if(is.data.frame(xtrn_df) && algo %in% c("glmnet", "svm", "svm.linear", "SGL"))
    xtrn = expand.df(xtrn_df)
  else
    xtrn = xtrn_df
  
  # feature selection for high dimensional data
  if(NCOL(xtrn) > 2*NROW(xtrn)){
    ftype = sapply(1:NCOL(xtrn), function(i) class(xtrn[,i]))
    if(is.factor(ytrn)){
      pv = double(NCOL(xtrn))
      pv[which(ftype=="factor")] = sapply(which(ftype == "factor"), function(i) chisq.test(xtrn[,i], ytrn)$p.value)
      pv[which(ftype=="numeric")] = sapply(which(ftype == "numeric"), function(i) wilcox.test(xtrn[,i] ~ ytrn)$p.value)
    }
    else
      pv = sapply(1:NCOL(xtrn), function(i) cor.test(xntr[,i], ytrn, method="spearman")$p.value)
    take = order(pv)[1:max.feat]
    xtrn = xtrn[,take]
    print(dim(xtrn))
  }
  if(is.factor(ytrn)){
    cfreq = table(ytrn)
    cfreq = cfreq / sum(cfreq)
    cfreq = 1/cfreq
  }
  else
    cfreq = NULL
  
  # default parameters
  idepth = 5
  ntrees = 5000
  formula = ytrn ~ xtrn
  if(!is.null(hyper)){
    if(!is.null(hyper$interaction.depth))
      idepth = hyper$interaction.depth
    if(!is.null(hyper$ntrees))
      ntrees = hyper$ntrees
    if(!is.null(hyper$formula))
      formula = hyper$formula
  }
  
  best.iter = NULL
  if(algo == "glmnet"){ # elastic net
    if(is.factor(ytrn)){
      if(nlevels(ytrn) == 2)
        family = "binomial"
      else
        family = "multinomial"
    }
    else{
      if(class(ytrn) == "Surv")
        family = "cox"
      else
        family = "gaussian"
    }
    best = Inf
    for(a in seq(0, 1, length.out = 10)){
      if(!is.null(weights))
        w = weights
      else
        w = rep(1, NROW(xtrn))
      fit.tmp = cv.glmnet(xtrn, ytrn, family=family, alpha=a, parallel=TRUE, weights=w) # tune elastic net penalty
      if(fit.tmp$cvm[fit.tmp$lambda == fit.tmp$lambda.min] < best){
        best = fit.tmp$cvm[fit.tmp$lambda == fit.tmp$lambda.min]
        fit = fit.tmp
      }
    }
    plot(fit)
    co = coef(fit, s="lambda.min")
    features = co[co[,1] != 0,]
  }
  else if(algo == "SGL"){ # sparse group lasso
    if(class(ytrn) == "Surv"){
      family = "cox"
      mydat = list(x=xtrn, time=ytrn[,1], status=ytrn[,2])
    }
    else{
      family = "linear"
      mydat = list(x=xtrn, y=ytrn)
    }
    best = Inf
    for(a in seq(0, 1, length.out = 10)){
      fit.tmp = cvSGL(mydat, index=hyper$index, type=family, alpha=a) # tune elastic net penalty
      if(min(fit.tmp$lldiff) < best){
        best = min(fit.tmp$lldiff)
        fit = fit.tmp
        co = fit.tmp$fit$beta[,which.min(fit.tmp$lldiff)]
      }
    }
    features = co[co[,1] != 0]
  }
  else if(algo == "RF"){  # Random Forests    
    fit = randomForest::tuneRF(xtrn, ytrn, plot=TRUE, doBest=TRUE, ntree=ntrees, importance=TRUE, keep.inbag=TRUE, classwt=cfreq) # tune final RF via OOB estimates
    var.imp = importance(fit, type=1)
    rf.sel = rfcv(xtrn, ytrn, ntree=ntrees) # perform feature selection
    nsel = rf.sel$n.var[which.min(rf.sel$error.cv)]
    features = var.imp[order(var.imp, decreasing=TRUE)[1:nsel]]
    names(features) = rownames(var.imp)[order(var.imp, decreasing=TRUE)[1:nsel]]
  }
  else if(algo %in% c("gbm", "gbm imp", "h2o-gbm")){ # Gradient Boosting Machine
    if(is.factor(ytrn)){
      if(nlevels(ytrn) == 2){
        distribution = "bernoulli"
        if(algo != "h2o-gbm")
          yy = as.numeric(ytrn) - 1
        else
          yy = ytrn
      }
      else{
        distribution = "multinomial"
        yy = ytrn
      }
    }
    else{
      distribution = "huber"
      yy = as.numeric(ytrn)
    }
    if(algo == "h2o-gbm"){
      myx = as.h2o(cbind(xtrn, data.frame(y=yy)))
      fit = h2o.gbm(colnames(xtrn), "y", training_frame=myx, nfolds=inner.cv, balance_classes=TRUE,  stopping_metric="mean_per_class_error", seed=1234567, ntrees=ntrees, score_tree_interval=10, stopping_rounds=5, sample_rate=0.9, col_sample_rate = 0.9, max_depth=idepth)
      print(fit)
      varimp = h2o.varimp(fit)
      varimp = varimp[varimp$percentage > 0, ]
      features = varimp$variable
    }
    else{
      fit = gbm(yy ~., data=data.frame(xtrn), distribution=distribution, interaction.depth=idepth, cv.folds=inner.cv, n.trees=ntrees, n.cores=10, weight=weights)
      best.iter = gbm.perf(fit, method="cv") # model selection based on cross-validation
      var.imp = summary(fit, plotit=FALSE, n.trees=best.iter)
      features = var.imp[var.imp[,2] > 0,]
    }
  }
  else if(algo == "gamboost"){
    if(is.factor(ytrn)){
      if(nlevels(ytrn) == 2)
        family = Binomial()
      else
        family = Multinomial()
    }
    else
      family = Huber()
    #ex = paste("data.frame(", as.character(form)[2], "= ytrn)")
    #eval(parse(text=ex))
    xtrn = as.list(cbind(data.frame(ytrn=ytrn), xtrn))
    if(attr(family, "name") == "Negative Multinomial Likelihood"){
      xtrn$class = factor(levels(ytrn)[-nlevels(ytrn)])
    }
    fit = gamboost(formula, data=xtrn, family=family, control=boost_control(mstop=ntrees), weights=weights)
    cvr = cvrisk(fit, mc.cores=ncores, folds=cv(model.weights(fit), type="kfold", B=inner.cv))
    best.iter = mstop(cvr)
    print(best.iter)
    plot(cvr)
    features = coef(fit[best.iter])
  }
  else if(algo == "svm"){ # SVM-RFE
    fit = svm.rfe(xtrn, ytrn, folds=inner.cv)
    features = fit$weights
  }
  else if(algo == "svm.linear"){ # SVM-RFE
    fit = svm.rfe(xtrn, ytrn, kernel="vanilladot", folds=inner.cv)
    features = fit$weights
  }
  list(fit=fit, xtrn=xtrn_df, orig.features=colnames(xtrn), features=features, algo=algo, is.classifier=is.factor(ytrn), best.iter=best.iter)
}

predict.model = function(model, xtst_df){
  fit=model$fit
  algo = model$algo
  cat("algorithm: ", algo, "\n\n")
  if(!(algo %in% c("gbm", "h2o-gbm")))
    xtst_df = impute.tst(model$xtrn, xtst_df)
  if(is.data.frame(xtst_df) && algo %in% c("glmnet", "svm", "svm.linear"))
    xtst = expand.df(xtst_df, model$orig.features)
  else
    xtst = xtst_df

  xtst = xtst[,model$orig.features]
  
  if(algo == "glmnet") # elastic net
    pred = predict(fit, xtst, s="lambda.min", type="response")
  else if(algo == "SGL")
    pred = predictSGL(fit$fit, xtst, lam=fit$lambdas[which.min(fit$lldiff)])
  else if(algo == "RF"){
    if(model$is.classifier)
      pred = predict(fit, xtst, type="prob")[,2]
    else
      pred = predict(fit, xtst)
  }
  else if(algo %in% c("gbm", "gbm imp")){ # Gradient Boosting Machine
    pred = predict(fit, newdata=data.frame(xtst), model$best.iter, type="response")
  }
  else if(algo == "h2o-gbm"){
    pred = as.data.frame(h2o.predict(fit, as.h2o(data.frame(xtst))))
    pred = pred[,-1]
  }
  else if(algo == "gamboost"){
    xtst = as.list(data.frame(xtst))
    if(attr(model$fit$family, "name") == "Negative Multinomial Likelihood")
      xtst$class = model$xtrn$class
    pred = predict(fit[model$best.iter], newdata=xtst, which=colnames(xtst), type="response")
  }
  else if(algo %in% c("svm", "svm.linear")){
    pred = predict(fit$fit, xtst[,fit$features,drop=FALSE], type="decision")
    pred = as.numeric(pred)
  }
  pred  
}

expand.df = function(dat2, variables=NULL){
  x = cbind(dummy(dat2[,sapply(1:NCOL(dat2), function(i) is.factor(dat2[,i]))]), dat2[,sapply(1:NCOL(dat2), function(i) is.numeric(dat2[,i]))])
  for(i in 1:NCOL(x))
    x[,i] = as.numeric(as.character(x[,i]))
  if(is.null(variables)){
    vars = apply(x, 2, var, na.rm=TRUE)
    x = x[,vars != 0 & !is.na(vars), drop=F] 
    x = x[,setdiff(1:NCOL(x), grep("MISSING", colnames(x)))] 
  }
  else
    x = x[,variables]
  x = as.matrix(x)
  x
}
